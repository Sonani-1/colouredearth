# Tool logic for email_tool.py
