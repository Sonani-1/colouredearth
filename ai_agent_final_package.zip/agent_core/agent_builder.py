# Code that builds the agent with tools, memory, and personality
