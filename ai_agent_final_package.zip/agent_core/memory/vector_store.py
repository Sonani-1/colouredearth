# Vector store memory logic
