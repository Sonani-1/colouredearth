# AI Agent - Astra

Full-featured GPT-4 agent with memory, tools, and UI.

## Setup
1. Install requirements
2. Set `.env`
3. Run `streamlit run app/app.py`
